#include <iostream>
using namespace std;
const int ROW_SIZE1=3;
const int COL_SIZE1=3;
const int ROW_SIZE2=3;
const int COL_SIZE2=3;


 
template <typename T>
class three_tupple_matrixll
{
    
    public:
    
    
    class node{
    public:
    int row;
    int col;
    T data;
    node * next;
    node(int r,int c,T d)
    {
        row=r;
        col=c;
        data=d;
        next=NULL;
    }
    };
    
    node * head ;
    void transpose(T arr[ROW_SIZE1][COL_SIZE1])
    {
        
        int m=ROW_SIZE1;
        int n=COL_SIZE1;
 
	    int count = 0;
	    node * temp,*ptr;
	    head=NULL;
	    for (int i = 0; i < m; i++)
	    {
		    for (int j = 0; j < n; j++)
		    {
			    if (arr[i][j] != 0)
			    {
			        count++;
			        ptr = new node(i,j,arr[i][j]);
			        if(count==1)
			        {
			            head=ptr;
			            temp=ptr;
			        }
			        else
			        {
			            temp->next=ptr;
			            temp=temp->next;
			        }
			  
			    }
		    }
	    }
	    
	    temp=head;
	    node * headt;
	    node * tempt;
	    //node * ptr;
	    node * tt1;
	    node * tt2;
	    while(temp!=NULL)
	    {
	        ptr =new node(temp->col,temp->row,temp->data);
	        if(headt==NULL)
	        {
	            headt=ptr;
	            
	            }
	        else
	        {
	            tt1=headt;
	            //tt2=headt;
	            int flag=0;
	            while(tt1!=NULL)
	            {
	                if(ptr->row < tt1->row || (ptr->row==tt1->row && ptr->col < tt1->col))
	                {
	                    if(tt1==headt)
	                    {
	                        headt=ptr;
	                        ptr->next=tt1;
	                    }
	                    else
	                    {
	                        tt2->next=ptr;
	                        ptr->next=tt1; 
	                    }
	                    flag=1;
	                    break;
	                }
	                else
	                {
	                    tt2=tt1;
	                    tt1=tt1->next;
	                }
	            }
	    
	            if (flag==0)
	            {
	                tt2->next=ptr;
	            }
	        }
	        temp=temp->next;
        }
         
         temp=headt;
         while(temp!=NULL)
	    {
	        cout <<temp->row<< " "<<temp->col<< " "<<temp->data<< " \n";
	        temp=temp->next;
	    }
    } 
    
    void add_matrix(T arr1[ROW_SIZE1][COL_SIZE1], T arr2[ROW_SIZE1][COL_SIZE1])
    {
        int m=ROW_SIZE1;
        int n=COL_SIZE1;
 
	    int count = 0;
	    node * heada, *headb;
	    node * temp,*ptr;
	    heada=NULL;
	    headb=NULL;
	    for (int i = 0; i < m; i++)
	    {
		    for (int j = 0; j < n; j++)
		    {
			    if (arr1[i][j] != 0)
			    {
			        count++;
			        ptr = new node(i,j,arr1[i][j]);
			        if(count==1)
			        {
			            heada=ptr;
			            temp=ptr;
			        }
			        else
			        {
			            temp->next=ptr;
			            temp=temp->next;
			        }
			  
			    }
		    }
	    }
	    
	    temp=NULL;
	    ptr=NULL;
	    count = 0;

	    for (int i = 0; i < m; i++)
	    {
		    for (int j = 0; j < n; j++)
		    {
			    if (arr2[i][j] != 0)
			    {
			        count++;
			        ptr = new node(i,j,arr2[i][j]);
			        if(count==1)
			        {
			            headb=ptr;
			            temp=ptr;
			        }
			        else
			        {
			            temp->next=ptr;
			            temp=temp->next;
			        }
			  
			    }
		    }
	    }
	    
	    node * tempa,*tempb,*tempc,*headc;
	    ptr=NULL;
	    headc=NULL;
	    tempa=heada;
	    tempb=headb;
	    tempc=headc;
	    
	 //   if (headb==NULL)
	  //      cout<< "NULL\n";
	    
	    while (tempa!=NULL || tempb!=NULL )
	    {
	        if (tempa==NULL)
	        {
	            while (tempb!=NULL)
	            {
	                ptr = new node(tempb->row,tempb->col,tempb->data);
	                if (tempc==NULL)
	                {
	                    headc=ptr;
	                }
	                else 
	                {
	                    tempc->next=ptr;
	                }
	                tempc=ptr;
	                tempb=tempb->next;
	            }
	        }
	        else if (tempb==NULL)
	        {
	           while (tempa!=NULL)
	            {
	                ptr = new node(tempa->row,tempa->col,tempa->data);
	                if (tempc==NULL)
	                {
	                    headc=ptr;
	                }
	                else 
	                {
	                    tempc->next=ptr;
	                }
	                tempc=ptr;
	                tempa=tempa->next;
	            } 
	        }
	        else if  ((tempa->row < tempb->row) || ((tempa->row == tempb->row) && (tempa->col < tempb->col)))
	       {
	            ptr = new node(tempa->row,tempa->col,tempa->data);
	            if (tempc==NULL)
	            {
	                headc=ptr;
	            }
	            else 
	            {
	                tempc->next=ptr;
	            }
	            tempc=ptr;
	            tempa=tempa->next;
	        }
	        
	       
	        else if ((tempa->row > tempb->row) || ((tempa->row == tempb->row) && (tempa->col > tempb->col)))
	        {
	            ptr = new node(tempb->row,tempb->col,tempb->data);
	            if (tempc==NULL)
	            {
	                headc=ptr;
	            }
	            else 
	            {
	                tempc->next=ptr;
	            }
	            tempc=ptr;
	            tempb=tempb->next;
	        }
	        else if ((tempa->row == tempb->row) && (tempa->col == tempb->col))
	        {
	            ptr = new node(tempa->row,tempa->col,tempa->data+tempb->data);
	            if (tempc==NULL)
	            {
	                headc=ptr;
	            }
	            else 
	            {
	                tempc->next=ptr;
	            }
	            tempc=ptr;
	            tempa=tempa->next;
	            tempb=tempb->next; 
	        }
	        
	      /* */  
	    }
	     tempc=headc;
	     cout <<"\nAdd Matrix\n";
         while(tempc!=NULL)
	    {
	        cout <<tempc->row<< " "<<tempc->col<< " "<<tempc->data<< " \n";
	        tempc=tempc->next;
	    }
	    
        
   }
   
   void multiply(T arr1[ROW_SIZE1][COL_SIZE1],T arr2[ROW_SIZE2][COL_SIZE2])
    {
        int m1=ROW_SIZE1;
        int n1=COL_SIZE1;
        int m2=ROW_SIZE2;
        int n2=COL_SIZE2;
    if( n1!=m2)
    {
        cout<<"Matrices can not be multiplied";
        return ;
    }
	int count1 = 0;
	node * head1=NULL;
	node * temp1,*ptr1;
	for (int i = 0; i < m1; i++)
	{
		for (int j = 0; j < n1; j++)
		{
			if (arr1[i][j] != 0)
			{
			    count1++;
			    ptr1 = new node(i,j,arr1[i][j]);
			    if(count1==1)
			    {
			        head1=ptr1;
			        temp1=ptr1;
			    }
			    else
			    {
			     temp1->next=ptr1;
			     temp1=temp1->next;
			    }
			  
			}
		}
	}
	
	
	int count2 = 0;
	node * head2=NULL;
	node * temp2,*ptr2;
	for (int i = 0; i < m2; i++)
	{
		for (int j = 0; j < n2; j++)
		{
			if (arr2[i][j] != 0)
			{
			    count2++;
			    ptr2 = new node(i,j,arr2[i][j]);
			    if(count2==1)
			    {
			        head2=ptr2;
			        temp2=ptr2;
			    }
			    else
			    {
			     temp2->next=ptr2;
			     temp2=temp2->next;
			    }
			  
			}
		}
	}
	node * tempa = head1;
	node * tempb;
	T sum =0;
	node * prod;
	node * headprod=NULL;
	node * tempprod=headprod;
	int atempcol[1000];   
    T atemp[1000];
    for(int i=0;i<m1;i++)
    {
        int crow=0;
        while(tempa!=NULL && tempa->row==i)
        {
            atempcol[crow]=tempa->col;   
            atemp[crow]=tempa->data;
            crow++;
            tempa=tempa->next;
        };
         
      if (crow==0)
      {
        for(int j=0;j<n2;j++)
        {
           
            sum=0;
            tempb = head2;
             while(tempb!=NULL )
            {
                if(tempb->col==j)
                {
                    for(int p=0;p<crow;p++)
                    {
                        if(atempcol[p]==tempb->row)
                        {
                            sum+=atemp[p]*tempb->data;
                            break;
                        }
                }
                tempb=tempb->next;
            }
            if(sum!=0)
            {
              prod = new node(i,j,sum);
              if(tempprod==NULL)
              {
                  headprod=prod;
                  tempprod=prod;      
              }
              else
              {
                  tempprod->next=prod;
                  tempprod=prod;
              }
            }
            
        }
        }
    }
    }
	tempprod=headprod;
	while(tempprod!=NULL)
	{
	    cout<<tempprod->row<<"  "<<tempprod->col<<"  "<<tempprod->data<<"\n";
	    tempprod=tempprod->next;
	}
	
}

    
};
int main() 
{
	// your code goes here
	double arr[ROW_SIZE1][COL_SIZE1]={1,44,0,7.5,0,2,5.5,0,90};
	double arr1[ROW_SIZE1][COL_SIZE1]={0,1,3.03,4,5,6.33,7,8.3,9};
	double arr2[ROW_SIZE1][COL_SIZE1]={10,11.5,12.6,13,14,15.45,16,17,18.19};
	double arr3[ROW_SIZE2][COL_SIZE2]={10,11.5,12.6,13,14,15.45,16,17,18.19};
	three_tupple_matrixll <double>ob1;
	ob1.transpose(arr);
	ob1.add_matrix(arr1, arr2);
	//ob1.multiply(arr1, arr3);
	return 0;
}